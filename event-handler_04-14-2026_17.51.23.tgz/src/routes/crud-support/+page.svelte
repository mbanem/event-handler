<script lang="ts">
	import type { PageProps } from './$types';
	import type { Models } from './parse-prisma-schema';
	let { data }: PageProps = $props();
	const data_ = () => {
		return data;
	};
	let uiModels = data_().models.uiModels as Models;
	let nuiModels = data_().models.nuiModels as Models;
	let ui_nui = [...Object.entries(uiModels), ...Object.entries(nuiModels)];
	console.log(Object.keys(ui_nui).length);
</script>

<div class="main">
	<pre>
		length {Object.keys(ui_nui).length}
	</pre>
</div>

<style lang="scss">
	.main {
		margin: 3rem 0 0 1rem;
		border: 1px solid gray;
		border-radius: 10px;
	}
</style>
