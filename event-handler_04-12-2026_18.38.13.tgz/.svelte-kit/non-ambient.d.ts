
// this file is generated — do not edit it


declare module "svelte/elements" {
	export interface HTMLAttributes<T> {
		'data-sveltekit-keepfocus'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-noscroll'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-preload-code'?:
			| true
			| ''
			| 'eager'
			| 'viewport'
			| 'hover'
			| 'tap'
			| 'off'
			| undefined
			| null;
		'data-sveltekit-preload-data'?: true | '' | 'hover' | 'tap' | 'off' | undefined | null;
		'data-sveltekit-reload'?: true | '' | 'off' | undefined | null;
		'data-sveltekit-replacestate'?: true | '' | 'off' | undefined | null;
	}
}

export {};


declare module "$app/types" {
	type MatcherParam<M> = M extends (param : string) => param is (infer U extends string) ? U : string;

	export interface AppTypes {
		RouteId(): "/" | "/Orm3" | "/OrmOne" | "/OrmThreex" | "/OrmThree" | "/OrmTwo" | "/boundary" | "/crinput" | "/crud-extension" | "/crud-support" | "/dd" | "/dots-on-click" | "/drag-drop" | "/draggable-list" | "/func-model" | "/grok-drag-drop" | "/grok-handler" | "/grok" | "/handle-model" | "/model" | "/page-router" | "/parse-prisma" | "/parse-problem" | "/parse" | "/pseudo-class" | "/regex-model" | "/sort-record" | "/static-class-model" | "/svelte-boundary" | "/test" | "/toggle-theme" | "/types" | "/w-map" | "/weak-map";
		RouteParams(): {
			
		};
		LayoutParams(): {
			"/": Record<string, never>;
			"/Orm3": Record<string, never>;
			"/OrmOne": Record<string, never>;
			"/OrmThreex": Record<string, never>;
			"/OrmThree": Record<string, never>;
			"/OrmTwo": Record<string, never>;
			"/boundary": Record<string, never>;
			"/crinput": Record<string, never>;
			"/crud-extension": Record<string, never>;
			"/crud-support": Record<string, never>;
			"/dd": Record<string, never>;
			"/dots-on-click": Record<string, never>;
			"/drag-drop": Record<string, never>;
			"/draggable-list": Record<string, never>;
			"/func-model": Record<string, never>;
			"/grok-drag-drop": Record<string, never>;
			"/grok-handler": Record<string, never>;
			"/grok": Record<string, never>;
			"/handle-model": Record<string, never>;
			"/model": Record<string, never>;
			"/page-router": Record<string, never>;
			"/parse-prisma": Record<string, never>;
			"/parse-problem": Record<string, never>;
			"/parse": Record<string, never>;
			"/pseudo-class": Record<string, never>;
			"/regex-model": Record<string, never>;
			"/sort-record": Record<string, never>;
			"/static-class-model": Record<string, never>;
			"/svelte-boundary": Record<string, never>;
			"/test": Record<string, never>;
			"/toggle-theme": Record<string, never>;
			"/types": Record<string, never>;
			"/w-map": Record<string, never>;
			"/weak-map": Record<string, never>
		};
		Pathname(): "/" | "/Orm3" | "/OrmOne" | "/OrmThreex" | "/OrmThree" | "/OrmTwo" | "/boundary" | "/crinput" | "/crud-extension" | "/crud-support" | "/dd" | "/dots-on-click" | "/drag-drop" | "/draggable-list" | "/func-model" | "/grok-drag-drop" | "/grok-handler" | "/grok" | "/handle-model" | "/model" | "/page-router" | "/parse-prisma" | "/parse-problem" | "/parse" | "/pseudo-class" | "/regex-model" | "/sort-record" | "/static-class-model" | "/svelte-boundary" | "/test" | "/toggle-theme" | "/types" | "/w-map" | "/weak-map";
		ResolvedPathname(): `${"" | `/${string}`}${ReturnType<AppTypes['Pathname']>}`;
		Asset(): "/favicon.png" | "/robots.txt" | string & {};
	}
}