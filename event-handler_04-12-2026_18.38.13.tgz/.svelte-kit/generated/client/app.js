export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12'),
	() => import('./nodes/13'),
	() => import('./nodes/14'),
	() => import('./nodes/15'),
	() => import('./nodes/16'),
	() => import('./nodes/17'),
	() => import('./nodes/18'),
	() => import('./nodes/19'),
	() => import('./nodes/20'),
	() => import('./nodes/21'),
	() => import('./nodes/22'),
	() => import('./nodes/23'),
	() => import('./nodes/24'),
	() => import('./nodes/25'),
	() => import('./nodes/26'),
	() => import('./nodes/27'),
	() => import('./nodes/28'),
	() => import('./nodes/29'),
	() => import('./nodes/30'),
	() => import('./nodes/31'),
	() => import('./nodes/32'),
	() => import('./nodes/33'),
	() => import('./nodes/34'),
	() => import('./nodes/35')
];

export const server_loads = [];

export const dictionary = {
		"/": [2],
		"/Orm3": [3],
		"/OrmOne": [4],
		"/OrmThreex": [6],
		"/OrmThree": [~5],
		"/OrmTwo": [7],
		"/boundary": [8],
		"/crinput": [9],
		"/crud-extension": [10],
		"/crud-support": [~11],
		"/dd": [12],
		"/dots-on-click": [13],
		"/drag-drop": [14],
		"/draggable-list": [15],
		"/func-model": [16],
		"/grok-drag-drop": [18],
		"/grok-handler": [19],
		"/grok": [17],
		"/handle-model": [20],
		"/model": [21],
		"/page-router": [22],
		"/parse-prisma": [24],
		"/parse-problem": [25],
		"/parse": [23],
		"/pseudo-class": [26],
		"/regex-model": [27],
		"/sort-record": [28],
		"/static-class-model": [29],
		"/svelte-boundary": [30],
		"/test": [31],
		"/toggle-theme": [32],
		"/types": [33],
		"/w-map": [34],
		"/weak-map": [35]
	};

export const hooks = {
	handleError: (({ error }) => { console.error(error) }),
	
	reroute: (() => {}),
	transport: {}
};

export const decoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.decode]));
export const encoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.encode]));

export const hash = false;

export const decode = (type, value) => decoders[type](value);

export { default as root } from '../root.js';