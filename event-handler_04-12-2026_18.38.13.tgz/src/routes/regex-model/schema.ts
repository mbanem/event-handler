export const schema = `
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
}

model User {
  id      			String   @id @default(uuid())
  firstName    	String   @map("first_name")
  lastName    	String   @map("last_name")
  email   			String
  passwordHash 	String   @map("password_hash")
  userAuthToken	String   @unique @map("user_auth_token")

  role          Role    @default(USER)
  posts   			Post[]
  profile 			Profile?

  articles      Article[]
  todos         Todo[]    // arrays are optional and could be empty

  createdAt DateTime @default(now())   @map("created_at")
  updatedAt DateTime? @updatedAt        @map("updated_at")

	@@unique(name): "fullNameEmail", [firstName, lastName, email])
  @@map("users")
}


enum Role {
  USER
  ADMIN
  VISITOR
  MODERATOR
}
model Profile {
  id     		String  @id @default(uuid())
  bio    		String?

  user   		User    @relation(fields: [userId], references: [id])
  userId 		String  @unique    @map("user_id")

  createdAt DateTime @default(now())   @map("created_at")
  updatedAt DateTime? @updatedAt        @map("updated_at")

  @@map("profile")
}
model Article {
    id      	String @id @default(uuid())
    title   	String
    content 	String
    author 	 	User 	 @relation(fields: [authorId], references: [id])
    authorId 	String @map("author_id")

    @@map("article")
}

model Post {
  id        String 	 @id @default(uuid())
  title     String   @db.VarChar(255)
  content   String?
  published Boolean  @default(false)

  author    User     @relation(fields: [authorId], references: [id])
  authorId  String   @map("author_id")

  categories Category[]

  createdAt DateTime @default(now())   @map("created_at")
  updatedAt DateTime? @updatedAt        @map("updated_at")

  @@map("post")
}

model Category {
  id    Int    @id @default(autoincrement())
  name  String

  @@map("category")
}
model Todo {
  id        String  @id @default(uuid())
  title     String
  content   String
  priority  Int     @default(0)
  completed Boolean @default(false)

  user   		User    @relation(fields: [userId], references: [id])
  userId 		String  @map("user_id")

  createdAt DateTime @default(now())   @map("created_at")
  updatedAt DateTime? @updatedAt        @map("updated_at")

  @@map("todo")
}
`